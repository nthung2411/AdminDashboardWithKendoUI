var mails = [{
    MailID : 1,
    FromID : 1,
    From : "Ivo Nedkov",
    Date : "2/22/2009",
    Title : "RE: New version of Telerik Trainer"
}, {
    MailID : 2,
    FromID : 2,
    From : "Jytte Petersen",
    Date : "2/22/2009",
    Title : "RE: New version of Telerik Trainer"
}, {
    MailID : 3,
    FromID : 3,
    From : "Renate Messner",
    Date : "2/22/2009",
    Title : "RE: Conferences?"
}, {
    MailID : 4,
    FromID : 4,
    From : "Kevin Babcock",
    Date : "2/21/2009",
    Title : "RE: Conferences?"
}, {
    MailID : 5,
    FromID : 5,
    From : "Hari Kumar",
    Date : "2/21/2009",
    Title : "RE: New 'Your Links' menu on telerik.com"
}, {
    MailID : 6,
    FromID : 3,
    From : "Renate Messner",
    Date : "2/21/2009",
    Title : "RE: Conferences?"
}, {
    MailID : 7,
    FromID : 6,
    From : "Anne Dodsworth",
    Date : "2/21/2009",
    Title : "RE: New 'Your Links' menu on telerik.com"
}, {
    MailID : 8,
    FromID : 7,
    From : "Janet Leverling",
    Date : "2/21/2009",
    Title : "RE: New 'Your Links' menu on telerik.com"
}, {
    MailID : 9,
    FromID : 9,
    From : "Rober King",
    Date : "2/21/2009",
    Title : "RE: New 'Your Links' menu on telerik.com"
}, {
    MailID : 10,
    FromID : 8,
    From : "Laura Callahan",
    Date : "2/20/2009",
    Title : "RE: Telerik Enters the ORM Space"
},{
    MailID : 11,
    FromID : 5,
    From : "Hari Kumar",
    Date : "2/20/2009",
    Title : "RE: New version of Telerik Trainer"
}, {
    MailID : 12,
    FromID : 2,
    From : "Jytte Petersen",
    Date : "2/20/2009",
    Title : "RE: New version of Telerik Trainer"
}, {
    MailID : 13,
    FromID : 4,
    From : "Kevin Babcock",
    Date : "2/20/2009",
    Title : "RE: Conferences?"
}, {
    MailID : 14,
    FromID : 3,
    From : "Renate Messner",
    Date : "2/20/2009",
    Title : "RE: Conferences?"
}, {
    MailID : 15,
    FromID : 1,
    From : "Ivo Nedkov",
    Date : "2/20/2009",
    Title : "RE: New 'Your Links' menu on telerik.com"
}];